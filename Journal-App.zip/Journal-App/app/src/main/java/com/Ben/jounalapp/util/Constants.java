package com.ben.jounalapp.util;

/**
 * Created by ben on Monday : 6/25/2018.
 */
public class Constants {

    public static final String DAIRYCOL = "Dairy";
    public static final String USERSCOL = "Users";
    public static final String DAIRYIDEXTRA = "DAIRYIDEXTRA";

}
